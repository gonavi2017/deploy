﻿CSS definitions are taken from http://buildserver.labs.intellij.net/viewType.html?buildTypeId=DotNetDiv_Service_IdeWebSchemes_BuildCssDefinitions
Feel free to update regularly.
