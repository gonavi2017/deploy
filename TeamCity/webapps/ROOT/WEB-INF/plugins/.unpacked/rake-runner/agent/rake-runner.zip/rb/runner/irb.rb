require "irb"

IRB.start(__FILE__)
